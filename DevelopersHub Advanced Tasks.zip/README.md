# DevelopersHub Corporation - Advanced Internship Tasks
**Intern ID:** DHC-1439  
**Due Date:** 9th June, 2026

## Overview
All 5 advanced AI/ML tasks completed in a single notebook: `DevelopersHub_Advanced_Tasks.ipynb`

## Tasks

| # | Task | Tech Used |
|---|------|-----------|
| 1 | News Topic Classifier (BERT) | Hugging Face Transformers, BERT fine-tuning |
| 2 | End-to-End ML Pipeline (Churn) | scikit-learn Pipeline, GridSearchCV, joblib |
| 3 | Multimodal Housing Price Prediction | PyTorch CNN, feature fusion |
| 4 | Context-Aware RAG Chatbot | LangChain, FAISS, sentence-transformers |
| 5 | Auto-Tagging Support Tickets | Prompt engineering, zero-shot vs few-shot |

## Results Summary

- **Task 1:** ~90% accuracy on AG News using BERT fine-tuned for 2 epochs
- **Task 2:** Random Forest pipeline with GridSearchCV — F1 ~0.60, AUC ~0.84 on Telco Churn
- **Task 3:** Multimodal CNN+tabular fusion — MAE ~$18k, RMSE ~$23k on housing prices
- **Task 4:** RAG chatbot with multi-turn memory using FAISS vector store
- **Task 5:** Few-shot tagging outperforms zero-shot on support ticket classification

## Setup

```bash
pip install -r requirements.txt
jupyter notebook DevelopersHub_Advanced_Tasks.ipynb
```

## Notes
- Tasks 3 and 4 use synthetic/local data so they run without any API keys
- For Task 4, swap `flan-t5-base` for `ChatOpenAI` or `ChatGroq` for better answers
- Task 2 pipeline is exported as `churn_pipeline.joblib` — ready to drop into a Flask endpoint
